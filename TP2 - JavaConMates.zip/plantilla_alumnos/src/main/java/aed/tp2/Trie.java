package aed.tp2;

public class Trie {
    private class Promocion {
        double factor;
        double tope;
        double millasOtorgadas;
        boolean tieneTope;

        Promocion(double factor) {
            this.factor = factor;
            this.tieneTope = false;
        }

        Promocion(double factor, double tope) {
            this.factor = factor;
            this.tope = tope;
            this.millasOtorgadas = 0;
            this.tieneTope = true;
        }
    }

    private class NodoTrie {
        NodoTrie[] hijos;
        Promocion promocion;

        NodoTrie() {
            hijos = new NodoTrie[26];
            promocion = null;
        }
    }

    private NodoTrie raiz;

    public Trie() {
        raiz = new NodoTrie();
    }

    private int indice(char c) {
        return Character.toUpperCase(c) - 'A';
    }

    public void insertar(String nombre, double factor) {
        insertarPromocion(nombre, new Promocion(factor));
    }

    public void insertarConTope(
            String nombre, double factor, double tope) {
        insertarPromocion(nombre, new Promocion(factor, tope));
    }

    private void insertarPromocion(String nombre, Promocion promocion) {
        NodoTrie actual = raiz;

        for (int i = 0; i < nombre.length(); i++) {
            int pos = indice(nombre.charAt(i));

            if (actual.hijos[pos] == null) {
                actual.hijos[pos] = new NodoTrie();
            }

            actual = actual.hijos[pos];
        }

        actual.promocion = promocion;
    }

    public boolean existe(String nombre) {
        return obtenerNodo(nombre) != null
                && obtenerNodo(nombre).promocion != null;
    }

    private NodoTrie obtenerNodo(String nombre) {
        NodoTrie actual = raiz;

        for (int i = 0; i < nombre.length(); i++) {
            int pos = indice(nombre.charAt(i));

            if (actual.hijos[pos] == null) {
                return null;
            }

            actual = actual.hijos[pos];
        }

        return actual;
    }

    public void eliminar(String nombre) {
        NodoTrie nodo = obtenerNodo(nombre);

        if (nodo != null && nodo.promocion != null) {
            nodo.promocion.factor = 1;
        }
    }

    public double obtenerFactor(String nombre) {
        NodoTrie nodo = obtenerNodo(nombre);

        if (nodo == null || nodo.promocion == null) {
            throw new RuntimeException("Promoción inexistente");
        }

        return nodo.promocion.factor;
    }

    public boolean tieneTope(String nombre) {
        NodoTrie nodo = obtenerNodo(nombre);

        if (nodo == null || nodo.promocion == null) {
            throw new RuntimeException("Promoción inexistente");
        }

        return nodo.promocion.tieneTope;
    }

    public double obtenerTope(String nombre) {
        NodoTrie nodo = obtenerNodo(nombre);

        if (nodo == null || nodo.promocion == null) {
            throw new RuntimeException("Promoción inexistente");
        }

        if (!nodo.promocion.tieneTope) {
            throw new RuntimeException("La promoción no tiene tope");
        }

        return nodo.promocion.tope;
    }
    public double calcularMillas(String nombre, double millasBase) {
        NodoTrie nodo = obtenerNodo(nombre); // Una sola búsqueda: O(|L|)

        if (nodo == null || nodo.promocion == null) {
            throw new RuntimeException("Promoción inexistente");
        }

        Promocion promo = nodo.promocion;
        double millasConPromo = millasBase * promo.factor;

        if (promo.tieneTope) {
            if (promo.millasOtorgadas + millasConPromo > promo.tope) {
                return millasBase;
            }

            promo.millasOtorgadas += millasConPromo;
        }

        return millasConPromo;
    }
}
